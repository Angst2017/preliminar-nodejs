# Changelog

## [2023-09-17] version 1.0.0 
 
### Added

- express app example
- tests example
- dockerfile and docker-compose
- github actions CI/CD automation

